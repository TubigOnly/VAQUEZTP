package com.example.vasquez_tp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        Button startbtn1 = findViewById(R.id.startbtn1);
        startbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start SecondActivity
                Intent intent = new Intent(home.this, parent.class);
                startActivity(intent);
                Toast.makeText(home.this, "Parent Game", Toast.LENGTH_SHORT).show();
                return;
            }
        });

        Button startbtn2 = findViewById(R.id.startbtn2);
        startbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start SecondActivity
                Intent intent = new Intent(home.this, kids.class);
                startActivity(intent);
                Toast.makeText(home.this, "Kids Game", Toast.LENGTH_SHORT).show();
                return;
            }
        });
    }
}
package com.example.vasquez_tp;

public class users {
    public String username;
    public String password;

    public users() {
        // Default constructor required for calls to DataSnapshot.getValue(users.class)
    }

    public users(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
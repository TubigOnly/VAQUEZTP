package com.example.vasquez_tp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class parent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_parent);

        LinearLayout linear1 = findViewById(R.id.linear1);
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(parent.this, parent_main.class);
                startActivity(intent);
                Toast.makeText(parent.this, "Morning Game", Toast.LENGTH_SHORT).show();
                return;
            }
        });

        LinearLayout linear2 = findViewById(R.id.linear2);
        linear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(parent.this, parent_main.class);
                startActivity(intent);
                Toast.makeText(parent.this, "Evening Game", Toast.LENGTH_SHORT).show();
                return;
            }
        });
    }
}